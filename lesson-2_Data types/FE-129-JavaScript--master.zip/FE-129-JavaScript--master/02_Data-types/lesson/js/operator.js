// Додавання " + "
// Віднімання " - "
// Множення " * "
// Ділення " / "
// Залишок від ділення " % "

//let num1 = 16 * 1000

let setNum = prompt("Введіть обєм Флешки")

let res = setNum * 1000


console.log(res / 820 + "mb");
console.log(res % 820 + "mb");